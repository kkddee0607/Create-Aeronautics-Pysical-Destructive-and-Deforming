# PDD 0.2.12-final source overlay

This is a **source overlay only** based on GitHub main SHA `8bfabca4973bcad625838e3ee92ef04f5236d655`, not a complete Gradle checkout and not a verified JAR build. It must be merged on top of the exact source checkout; uploading it directly into a destructive full-project replacement workflow will delete the other source files.

The required design contract is §14.1–14.2 of `docs/PDD-1.0.1-Integrated-Design-Specification.md`.

## Integration edits required in the existing entry point

The overlay adds `AcceptanceReport`, `CollisionAcceptanceMetrics`, `RawObservationDispatcher`, and the corrected bounded intake. In the original `PhysicalDestroyDeform` class:

1. Set `BUILD_VERSION` to `0.2.12-final`.
2. Add a final `AcceptanceReport report = new AcceptanceReport();` field (using the `com.physicaldestroydeform.diagnostics.AcceptanceReport` import).
3. After `var callbacks = SableContactQueue.drain();` in `onServerTick`, call `RawObservationDispatcher.dispatch(callbacks);` even when verbose logging is disabled.
4. Call `report.log(LOGGER);` every 100 server ticks **before** any `if (!debugCollisions) return;` statement. Do not log each callback in normal operation.
5. Call `report.close();` when the server stops, to avoid retaining consumers across integrated server restarts.

**Known limitation:** These entry-point edits are documented but NOT applied in the zip because the complete baseline source could not be fetched into the local workspace. Thus this is a reviewable partial implementation, *not* an all-in-one ready-to-apply release. Do not label this package as a completed final version.

## Required verification

See `docs/verification/0.2.12-final.md`. Successful source compilation alone is insufficient: `G-COL-01` requires in-game behavior parity for Fragile/Belt/TNT and ordinary stone/wood collision observation.
