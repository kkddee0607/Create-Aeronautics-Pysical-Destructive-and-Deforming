#!/usr/bin/env python3
"""Validate a ZIP's recognizable project root before using GitHub Apply PDD ZIP.
Does not claim Gradle, JUnit, Sable, or in-game success.
"""
import pathlib,sys,zipfile

def main(path):
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failed')
        files={v.filename.rstrip('/') for v in z.infolist() if not v.is_dir()}
        candidates=[]
        for f in files:
            if f.endswith('build.gradle'):
                root=f[:-len('build.gradle')]
                if root+'settings.gradle' in files and any(x.startswith(root+'src/main/java/') for x in files):
                    candidates.append(root)
        if len(candidates)!=1:
            raise ValueError('ZIP must contain exactly one recognizable Gradle Java project root: '+repr(candidates))
        root=candidates[0]
        needed=['gradlew','gradlew.bat','gradle/wrapper/gradle-wrapper.jar',
                'gradle/wrapper/gradle-wrapper.properties']
        missing=[n for n in needed if root+n not in files]
        if missing:raise ValueError('missing Gradle contract files: '+repr(missing))
        if not any(x.startswith(root+'src/test/java/') for x in files):
            raise ValueError('missing src/test/java tests')
        print('PASS: one project root',repr(root),'CRC OK; files',len(files))
if __name__=='__main__':
    try:main(pathlib.Path(sys.argv[1]))
    except Exception as ex:
        print('FAIL:',ex,file=sys.stderr)
        sys.exit(1)
