#!/usr/bin/env python3
"""Build a PDD 0.3.0realFix candidate from SHA-verified GitHub original source.

Supports either a local Git checkout OR individually fetched, cryptographically
verified GitHub file blobs. Never uploads to GitHub or alters its repository.
"""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, sys, tempfile, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
EXPECTED_SHA = '55972847736adad106d4b883f6b943b6217a644a'
SRC_PREFIX = pathlib.Path('src/main/java/com/physicaldestroydeform')
ZIP_NAME = 'PDD-0.3.0realFix-FULL-SOURCE-BUILD-PENDING.zip'


def run(argv, cwd, *, required=True):
    r = subprocess.run(argv, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print('$', ' '.join(argv), 'status=', r.returncode)
    if r.stdout: print(r.stdout[-3000:])
    if required and r.returncode: raise RuntimeError('command failed: ' + ' '.join(argv))
    return r


def validate_root(base):
    required = ['build.gradle', 'settings.gradle', 'gradlew', 'gradlew.bat',
                'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties',
                'src/main/java', 'src/test/java', '.github/workflows/apply-pdd-zip.yml']
    missing = [p for p in required if not (base/p).exists()]
    if missing: raise RuntimeError('not a complete PDD source checkout: ' + repr(missing))


PROTECTED_CONTRACT = {
    'gradlew','gradlew.bat','gradle/wrapper/gradle-wrapper.jar',
    'gradle/wrapper/gradle-wrapper.properties','settings.gradle','gradle.properties',
    '.github/workflows/apply-pdd-zip.yml','.github/workflows/build-gradle.yml',
    '.github/workflows/pdd-callback-test.yml','.github/workflows/import-pdd-issues.yml',
}
CHANGED_EXISTING = {
    'build.gradle',
    'src/main/java/com/physicaldestroydeform/PhysicalDestroyDeform.java',
    'src/main/java/com/physicaldestroydeform/mixin/SableUniversalCallbackMixin.java',
    'src/main/java/com/physicaldestroydeform/diagnostics/NativeCollisionTelemetry.java',
    'src/main/resources/META-INF/neoforge.mods.toml',
}

def git_blob_sha(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode('ascii')+b'\0'+data).hexdigest()

def verify_original(stage,excluding_mutable):
    inventory=stage/'GITHUB-SOURCE-INVENTORY.json'
    if inventory.exists():
        manifest=json.loads(inventory.read_text(encoding='utf-8'))
        if manifest['commit']!=EXPECTED_SHA or manifest['fileCount']!=109:
            raise RuntimeError('original source inventory SHA/count mismatch')
        mismatches=[]
        for record in manifest['files']:
            rel=record['path']
            if excluding_mutable and rel in CHANGED_EXISTING: continue
            actual=stage/rel
            if not actual.is_file() or git_blob_sha(actual.read_bytes())!=record['gitBlobSha']:
                mismatches.append(rel)
        if mismatches:raise RuntimeError(f'baseline original file modified or missing: {mismatches[:15]}')
        print(f'GITHUB_SOURCE_SHA_VERIFIED={manifest["fileCount"]}, '
              f'protectedContracts={len(PROTECTED_CONTRACT)}, mutable={excluding_mutable}')
    elif excluding_mutable:
        print('WARN: No GitHub blob inventory; full SHA verification applies only in fetch-individual-blobs mode')
    for rel in PROTECTED_CONTRACT:
        if not (stage/rel).is_file():raise RuntimeError('missing protected contract: '+rel)


def modify_source(base):
    # Overlays from independently tested 1.0.5-A gameplay-credit core.
    package = SRC_PREFIX/'collision'
    (base/package).mkdir(parents=True,exist_ok=True)
    for name in ['GameImpactCredit.java', 'NativeEffectGroups.java',
                 'GameImpactDispatch.java', 'OwnerLocalTargetCandidates.java',
                 'RealFixBoundsEvidence.java', 'RealFixBoundaryCandidates.java', 'RealFixRuntimeBridge.java']:
        shutil.copy2(ROOT/'src/main/java/com/physicaldestroydeform/collision'/name,
                     base/package/name)
    for name in ['GameImpactCreditTest.java', 'RealFixBoundsEvidenceTest.java', 'RealFixBoundaryCandidatesTest.java']:
        p = pathlib.Path('src/test/java/com/physicaldestroydeform/collision')
        (base/p).mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/p/name, base/p/name)

    # Preserve Sable's null callback / native registration behavior.
    callback = base/SRC_PREFIX/'mixin/SableUniversalCallbackMixin.java'
    contents = callback.read_text(encoding='utf-8')
    old = 'if (state.isAir()) return original;'
    if old in contents:
        contents = contents.replace(old, 'if (state.isAir() || original == null) return original;', 1)
    elif 'if (state.isAir() || original == null) return original;' not in contents:
        raise RuntimeError('Sable callback interception signature changed; source not edited')
    callback.write_text(contents, encoding='utf-8')

    build = base/'build.gradle'
    contents = build.read_text(encoding='utf-8')
    if "version = '0.3.0-moreRog'" not in contents and "version = '0.3.0realFix'" not in contents:
        raise RuntimeError('unexpected build.gradle version; refusing speculative rewrite')
    build.write_text(contents.replace("version = '0.3.0-moreRog'", "version = '0.3.0realFix'"),encoding='utf-8')
    # Replace the actual live 0.3.0-moreRog entrypoint, not just its version label.
    old_main=base/SRC_PREFIX/'PhysicalDestroyDeform.java'
    prior=old_main.read_text(encoding='utf-8')
    if 'ImpactLiveAudit.evaluate' not in prior or 'SableContactQueue.drain()' not in prior:
        raise RuntimeError('moreRog live pipeline changed; review integration before replacing')
    shutil.copy2(ROOT/SRC_PREFIX/'PhysicalDestroyDeform.java',old_main)

    # Original native feed must be active independently of diagnostic verbosity.
    telemetry=base/SRC_PREFIX/'diagnostics/NativeCollisionTelemetry.java'
    txt=telemetry.read_text(encoding='utf-8')
    original='public static final boolean ENABLED = Boolean.parseBoolean(System.getProperty("pdd.debugCollisions", "true"))\n            || Boolean.parseBoolean(System.getProperty("pdd.proxy.enabled", "false"));'
    if original not in txt:raise RuntimeError('NativeCollisionTelemetry enable gate changed')
    telemetry.write_text(txt.replace(original,'public static final boolean ENABLED = true;',1),encoding='utf-8')

    # Correct Mod metadata and manifest; DO NOT touch Gradle/NeoForge/JUnit dependencies.
    mods=base/'src/main/resources/META-INF/neoforge.mods.toml'
    m=mods.read_text(encoding='utf-8')
    if '0.3.0-moreRog' not in m:raise RuntimeError('Mod metadata version changed')
    mods.write_text(m.replace('0.3.0-moreRog','0.3.0realFix').replace(
        'read-only native-normal and rotation rejection diagnostics. Preserves existing impact proxy policy, original callbacks and world mutation OFF.',
        'IDS 1.0.5-A read-only Sable native game impact bridge, owner-local audit and one-credit FSM. No world mutation.'),encoding='utf-8')
    # Preserve both the base document and the new normative 1.0.5 revision.
    docs = base/'docs'
    docs.mkdir(exist_ok=True)
    shutil.copy2(ROOT/'docs/PDD-1.0.5-A-Integrated-Design-Specification.md',
                 docs/'PDD-1.0.5-Integrated-Design-Specification.md')
    (base/'docs/verification/0.3.0realFix-rebuild.txt').write_text(
        'Source-rebuild using 1.0.5-A realFix live bridge and developer-default credit core.\n'
        'DO NOT represent this as a released or in-game validated 0.3.0realFix.\n', encoding='utf-8')


def make_zip(src, dest):
    items = sorted(p for p in src.rglob('*') if p.is_file()
                   and '.git' not in p.parts and 'incoming' not in p.parts
                   and 'build' not in p.parts and '.gradle' not in p.parts)
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in items: z.write(p,p.relative_to(src).as_posix())
    with zipfile.ZipFile(dest) as z:
        bad=z.testzip()
        if bad: raise RuntimeError('bad ZIP member '+bad)
        names=set(z.namelist())
        roots=[p for p in names if p.endswith('build.gradle')]
        project_ok= len(roots)==1 and roots[0]=='build.gradle' and {'settings.gradle',
                    'gradlew','gradlew.bat','gradle/wrapper/gradle-wrapper.jar'} <= names and \
                    any(p.startswith('src/main/java/') for p in names) and \
                    any(p.startswith('src/test/java/') for p in names)
        if not project_ok: raise RuntimeError('Apply root validation failed')
    return len(items),hashlib.sha256(dest.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo',type=pathlib.Path,default=pathlib.Path.cwd(),help='GitHub PDD source checkout')
    ap.add_argument('--output',type=pathlib.Path,default=pathlib.Path.cwd()/ZIP_NAME)
    ap.add_argument('--fetch-individual-blobs',action='store_true',
                    help='fetch all 109 GitHub original blobs individually (no clone or archive)')
    ap.add_argument('--skip-gradle',action='store_true',help='emit clearly UNVERIFIED source ZIP only')
    args=ap.parse_args()
    repo=args.repo.resolve();dest=args.output.resolve()
    with tempfile.TemporaryDirectory(prefix='pdd-realfix-') as d:
        stage=pathlib.Path(d)/'project'
        if args.fetch_individual_blobs:
            from github_source_builder import restore
            restore(stage,os.environ.get('GITHUB_TOKEN',''),EXPECTED_SHA)
        else:
            validate_root(repo)
            current=run(['git','rev-parse','HEAD'],repo).stdout.strip()
            if current!=EXPECTED_SHA:
                raise RuntimeError(f'GitHub main changed: {current} != {EXPECTED_SHA}; inspect changes first')
            shutil.copytree(repo,stage,ignore=shutil.ignore_patterns('.git','incoming','build','.gradle'))
        verify_original(stage,excluding_mutable=False)
        modify_source(stage)
        validate_root(stage)
        verify_original(stage,excluding_mutable=True)
        if not args.skip_gradle:
            # Java/NeoForge caches must exist in this environment. Neither task is faked.
            run(['bash','./gradlew','clean','test','--no-daemon'],stage)
            run(['bash','./gradlew','build','--no-daemon'],stage)
        else:
            (stage/'UNVERIFIED-NOT-FOR-APPLY.txt').write_text(
                'Gradle was not executed. This bundle is NOT a verified release.\n')
        dest.parent.mkdir(parents=True,exist_ok=True)
        n,sha=make_zip(stage,dest)
        print(f'ZIP_PATH={dest}\nZIP_FILES={n}\nSHA256={sha}\nGRADLE_VERIFIED={not args.skip_gradle}')
        print('WARNING: in-game R1 target coverage and R2-R4 uncalibrated paths are NOT VERIFIED.')
        print('Do not declare release acceptance until official Gradle/Actions and game gates pass.')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(f'FAILED: {exc}',file=sys.stderr)
        sys.exit(1)
