#!/usr/bin/env python3
"""Pin and reconstruct every PDD GitHub main file via individual Git blob reads.

Requires GitHub network access in the *execution environment*.  This is
an explicit alternative to a Git clone/archive and does not alter the remote
repository.  Files are verified against the Git object SHA from the tree.
"""
from __future__ import annotations
import argparse, base64, hashlib, json, os, pathlib, shutil, subprocess, sys, time
import urllib.error, urllib.request

REPO = 'kkddee0607/Create-Aeronautics-Pysical-Destructive-and-Deforming'
EXPECTED_HEAD = '55972847736adad106d4b883f6b943b6217a644a'
API = f'https://api.github.com/repos/{REPO}'

class GitHubError(RuntimeError): pass

def fetch_json(path, token, retries=3):
    url = f'{API}/{path.lstrip("/")}'
    headers = {'Accept':'application/vnd.github+json',
               'X-GitHub-Api-Version':'2022-11-28','User-Agent':'PDD-source-rebuilder'}
    if token: headers['Authorization']='Bearer '+token
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=45) as r:
                return json.load(r)
        except (urllib.error.URLError, TimeoutError) as exc:
            if attempt==retries-1: raise GitHubError(f'GET {url}: {exc}') from exc
            time.sleep(attempt+1)

def git_sha(blob: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(blob)).encode('ascii')+b'\0'+blob).hexdigest()

def validated_relative_path(path):
    parts=pathlib.PurePosixPath(path)
    if parts.is_absolute() or not parts.parts or '..' in parts.parts or '\\' in path:
        raise GitHubError('unsafe repository path: '+repr(path))
    return pathlib.Path(*parts.parts)

def restore(root, token, expected=EXPECTED_HEAD, *, trace=True):
    branch=fetch_json('branches/main',token)
    actual=branch['commit']['sha']
    if actual!=expected:
        raise GitHubError(f'main SHA changed: {actual} != {expected}; refuses to mix versions')
    tree=fetch_json(f'git/trees/{expected}?recursive=1',token)
    if tree.get('truncated'): raise GitHubError('tree truncated')
    blobs=[e for e in tree['tree'] if e['type']=='blob']
    if len(blobs)!=109:
        raise GitHubError(f'baseline expected 109 files, got {len(blobs)}')
    restored=[]
    root.mkdir(parents=True,exist_ok=True)
    for ix, entry in enumerate(blobs,1):
        rel=validated_relative_path(entry['path'])
        obj=fetch_json('git/blobs/'+entry['sha'],token)
        if obj['encoding']!='base64':raise GitHubError(f'blob encoding {rel}: {obj["encoding"]}')
        data=base64.b64decode(obj['content'])
        if (git_sha(data)!=entry['sha'] or len(data)!=entry['size'] or obj['sha']!=entry['sha']):
            raise GitHubError('SHA/size mismatch: '+str(rel))
        target=root/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        if entry['path']=='gradlew' or entry.get('mode')=='100755':target.chmod(0o755)
        restored.append({'path':entry['path'],'bytes':len(data),'gitBlobSha':entry['sha']})
        if trace and (ix%10==0 or ix==len(blobs)):
            print(f'Verified {ix}/{len(blobs)} files',flush=True)
    (root/'GITHUB-SOURCE-INVENTORY.json').write_text(json.dumps({
        'source':'GitHub REST, individual git blobs','repository':REPO,
        'commit':expected,'fileCount':len(restored),'files':restored
    },indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return len(restored)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',required=True,help='empty local directory to rebuild GitHub main into')
    p.add_argument('--ref',default=EXPECTED_HEAD)
    p.add_argument('--token-env',default='GITHUB_TOKEN')
    args=p.parse_args()
    output=pathlib.Path(args.output).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        raise GitHubError(f'Output directory is not empty: {output}')
    token=os.getenv(args.token_env,'')
    if not token and shutil.which('gh'):
        probe=subprocess.run(['gh','auth','token'],text=True,capture_output=True,timeout=10)
        if probe.returncode==0:token=probe.stdout.strip()
    print(f'Reconstructing {REPO}@{args.ref}, network and GitHub read access required.',flush=True)
    count=restore(output,token,args.ref)
    required=['build.gradle','settings.gradle','gradlew',
             'gradle/wrapper/gradle-wrapper.jar',
             'src/main/java/com/physicaldestroydeform/PhysicalDestroyDeform.java',
             'src/test/java/com/physicaldestroydeform/diagnostics/ObservingCollisionCallbackTest.java',
             '.github/workflows/apply-pdd-zip.yml']
    for f in required:
        if not (output/f).is_file():raise GitHubError('missing protected file: '+f)
    print(f'PASS: {count} GitHub files reconstructed and individually SHA-verified at {output}')

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print('RESTORE FAILED:',ex,file=sys.stderr);sys.exit(1)
