#!/usr/bin/env python3
"""Java21 syntax + interface type check with isolated TEST-ONLY stubs.
NOT NeoForge/JUnit; placeholders never enter the distribution.
"""
from pathlib import Path
import subprocess, shutil
root=Path(__file__).parent
stubs=root/'build/aux-stubs'
files={
 'net/minecraft/core/BlockPos.java':'''package net.minecraft.core;public record BlockPos(int getX,int getY,int getZ){}''',
'net/minecraft/world/level/ChunkPos.java':'''package net.minecraft.world.level;import net.minecraft.core.BlockPos;public record ChunkPos(BlockPos pos){}''',
'net/minecraft/core/registries/BuiltInRegistries.java':'''package net.minecraft.core.registries;public class BuiltInRegistries {public static final Registry BLOCK=new Registry();public static class Registry{public String getKey(Object block){return "minecraft:stone";}}}''',
 'org/slf4j/Logger.java':'''package org.slf4j; public interface Logger {default void info(String s,Object... a){} default void warn(String s,Object... a){} default void error(String s,Object... a){} }''',
'org/slf4j/LoggerFactory.java':'''package org.slf4j;public class LoggerFactory {public static Logger getLogger(Class<?> c){return new Logger(){};}}''',
'net/neoforged/fml/common/Mod.java':'''package net.neoforged.fml.common;import java.lang.annotation.*;@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.TYPE)public @interface Mod{String value();}''',
'net/neoforged/neoforge/common/NeoForge.java':'''package net.neoforged.neoforge.common; import java.util.function.Consumer; public class NeoForge {public static final Bus EVENT_BUS=new Bus();public static class Bus {public <T> void addListener(Consumer<T> f){}}}''',
'net/neoforged/neoforge/event/OnDatapackSyncEvent.java':'''package net.neoforged.neoforge.event;import net.minecraft.server.MinecraftServer;public class OnDatapackSyncEvent {public Object getPlayer(){return null;}public PlayerList getPlayerList(){return new PlayerList();}public static class PlayerList{public MinecraftServer getServer(){return new MinecraftServer();}}}''',
'net/neoforged/neoforge/event/server/ServerStartedEvent.java':'''package net.neoforged.neoforge.event.server;import net.minecraft.server.MinecraftServer;public class ServerStartedEvent {public MinecraftServer getServer(){return new MinecraftServer();}}''',
'net/neoforged/neoforge/event/server/ServerStoppedEvent.java':'''package net.neoforged.neoforge.event.server;public class ServerStoppedEvent{}''',
'net/neoforged/neoforge/event/tick/ServerTickEvent.java':'''package net.neoforged.neoforge.event.tick;import net.minecraft.server.MinecraftServer;public class ServerTickEvent {public static class Post {public MinecraftServer getServer(){return new MinecraftServer();}}}''',
'com/physicaldestroydeform/material/MaterialRegistry.java':'''package com.physicaldestroydeform.material;import net.minecraft.server.MinecraftServer;import org.slf4j.Logger;public class MaterialRegistry {public static void rebuild(MinecraftServer s,Logger l){}public static void clear(){}}''',
'com/physicaldestroydeform/diagnostics/AcceptanceReport.java':'''package com.physicaldestroydeform.diagnostics;import org.slf4j.Logger;public class AcceptanceReport {public void close(){}public void log(Logger l){}}''',
'com/physicaldestroydeform/diagnostics/PddDiagnostics.java':'''package com.physicaldestroydeform.diagnostics;import org.slf4j.Logger;public class PddDiagnostics {public static boolean runModelSelfTest(Logger l){return true;}}''',
'com/physicaldestroydeform/diagnostics/RawObservationDispatcher.java':'''package com.physicaldestroydeform.diagnostics;import java.util.List;public class RawObservationDispatcher {public static void dispatch(List<RawObservation> l){}}''',
'com/physicaldestroydeform/collision/SableFrameCapture.java':'''package com.physicaldestroydeform.collision;import java.util.List;public class SableFrameCapture {public static List<CollisionFrame.Snapshot> drainPreHistory(){return List.of();}public static void clear(){}public static String summary(){return "";}}''',

'net/minecraft/server/MinecraftServer.java':'''package net.minecraft.server; import net.minecraft.server.level.ServerLevel; import java.util.List;public class MinecraftServer {public long getTickCount(){return 1;}public Iterable<ServerLevel> getAllLevels(){return List.of();}}''',
'net/minecraft/server/level/ServerLevel.java':'''package net.minecraft.server.level;public class ServerLevel {public boolean hasChunkAt(net.minecraft.core.BlockPos p){return true;}public State getBlockState(net.minecraft.core.BlockPos p){return new State();}public static class State {public boolean isAir(){return false;}public Shape getCollisionShape(ServerLevel level,net.minecraft.core.BlockPos pos){return new Shape();}public static class Shape {public boolean isEmpty(){return false;}}public Object getBlock(){return new Object();}public String toString(){return "minecraft:stone";}}public Dimension dimension(){return new Dimension();}public static class Dimension {public Object location(){return "minecraft:overworld";}}}''',
'dev/ryanhcode/sable/api/sublevel/SubLevelContainer.java':'''package dev.ryanhcode.sable.api.sublevel;import net.minecraft.server.level.ServerLevel;import dev.ryanhcode.sable.sublevel.ServerSubLevel;import java.util.List;public class SubLevelContainer {public boolean inBounds(net.minecraft.world.level.ChunkPos p){return false;}public Object getPlot(net.minecraft.world.level.ChunkPos p){return null;}public static SubLevelContainer getContainer(ServerLevel l){return new SubLevelContainer();} public List<ServerSubLevel> getAllSubLevels(){return List.of();}}''',
'dev/ryanhcode/sable/sublevel/ServerSubLevel.java':'''package dev.ryanhcode.sable.sublevel;import java.util.UUID;public class ServerSubLevel {public boolean isRemoved(){return false;}public UUID getUniqueId(){return UUID.randomUUID();}public Box boundingBox(){return new Box();}public static class Box {public double minX(){return 0;}public double minY(){return 0;}public double minZ(){return 0;}public double maxX(){return 1;}public double maxY(){return 1;}public double maxZ(){return 1;}}}''',
'com/physicaldestroydeform/collision/CollisionFrame.java':'''package com.physicaldestroydeform.collision;import java.util.List;import java.util.UUID; public class CollisionFrame {public enum Phase{PRE_SOLVER,POST_SOLVER}public enum Space{STATIC_WORLD,SABLE_PLOT}public record BlockTarget(Space space,String dimension,UUID stablePlotId,boolean valid){}public record Evidence(long epoch,long serverTick,String dimension,Phase phase,BlockTarget hit,BlockTarget other){} public record Body(int runtimeId,UUID plotId) {public boolean ownerCandidateValid(){return true;}} public record Snapshot(Phase phase,boolean containerAvailable,long serverTick,String dimension,List<Body> bodies){} }''',
'com/physicaldestroydeform/collision/OwnerResolver.java':'''package com.physicaldestroydeform.collision; import net.minecraft.server.MinecraftServer; import java.util.Map; import java.util.UUID;public class OwnerResolver {public record CacheKey(CollisionFrame.BlockTarget key,String block){}public record TargetKey(int x,int y,int z,String fingerprint){}public record Check(boolean verified,TargetKey key){}public record Pair(Check hit,Check other){}public static Pair audit(MinecraftServer s,CollisionFrame.Evidence e,String b,Map<CacheKey,Check> c){return new Pair(new Check(false,null),new Check(false,null));}}''',
'com/physicaldestroydeform/diagnostics/RawObservation.java':'''package com.physicaldestroydeform.diagnostics;public record RawObservation(boolean hasOther,com.physicaldestroydeform.collision.CollisionFrame.Evidence frameEvidence,String blockId){}''',
'com/physicaldestroydeform/diagnostics/SableContactQueue.java':'''package com.physicaldestroydeform.diagnostics;import java.util.List;public class SableContactQueue {public static long dropped(){return 0;}public static long total(){return 0;}public static List<RawObservation> drain(){return List.of();}}''',
'com/physicaldestroydeform/diagnostics/NativeCollisionTelemetry.java':'''package com.physicaldestroydeform.diagnostics;import java.util.List;public class NativeCollisionTelemetry {public static long dropped(){return 0;}public static long malformed(){return 0;}public static long total(){return 0;}public static List<Contact> drain(){return List.of();}public record Contact(int idA,int idB,double rawImpactScalar,double ax,double ay,double az,double bx,double by,double bz,double contactAX,double contactAY,double contactAZ,double contactBX,double contactBY,double contactBZ,String dimension,long serverTick){} }''',
}
for name,content in files.items():
 p=stubs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content+'\n',encoding='utf-8')
source=root/'src/main/java/com/physicaldestroydeform/collision'
cls=root/'build/aux-compiled'
cls.mkdir(parents=True,exist_ok=True)
code=[source/(x+'.java') for x in ('GameImpactCredit','NativeEffectGroups','RealFixBoundsEvidence','RealFixBoundaryCandidates','RealFixRuntimeBridge')] + [root/'src/main/java/com/physicaldestroydeform/PhysicalDestroyDeform.java']
cmd=['javac','--release','21','-Xlint:all','-d',str(cls),*map(str,stubs.rglob('*.java')),*map(str,code)]
r=subprocess.run(cmd,capture_output=True,text=True)
print('RealFixRuntimeBridge aux javac exit',r.returncode)
if r.stdout:print(r.stdout)
if r.stderr:print(r.stderr[-16000:])
raise SystemExit(r.returncode)
