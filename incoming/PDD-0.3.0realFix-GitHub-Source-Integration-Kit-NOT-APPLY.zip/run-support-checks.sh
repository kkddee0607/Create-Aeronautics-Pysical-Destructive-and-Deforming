#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/check
javac --release 21 -Xlint:all -d build/check \
  src/main/java/com/physicaldestroydeform/collision/{GameImpactCredit,NativeEffectGroups,GameImpactDispatch,OwnerLocalTargetCandidates,RealFixBoundsEvidence,RealFixBoundaryCandidates}.java \
  src/test/java/com/physicaldestroydeform/collision/{GameImpactCreditFixture,NativeEffectGroupsFixture,GameImpactDispatchFixture,OwnerLocalTargetCandidatesFixture,RealFixBoundsEvidenceFixture,RealFixBoundaryCandidatesFixture}.java
for name in GameImpactCreditFixture NativeEffectGroupsFixture GameImpactDispatchFixture OwnerLocalTargetCandidatesFixture RealFixBoundsEvidenceFixture RealFixBoundaryCandidatesFixture; do
  java -cp build/check "com.physicaldestroydeform.collision.${name}"
done
