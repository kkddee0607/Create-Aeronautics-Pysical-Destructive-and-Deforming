# PDD 0.3.0realFix source reconstruction & implementation integration kit

**NOT AN APPLY ZIP.** This package includes the new Java server entrypoint and runtime bridge, bounded game-credit/R4-provisional core, source-integrity downloader, regression tests, and integration builder. It does **not** contain all 109 GitHub original source files inside this ZIP, so uploading this kit to `incoming/` would violate the Apply contract.

GitHub baseline: `55972847736adad106d4b883f6b943b6217a644a`. Normative: `docs/PDD-1.0.5-A-Integrated-Design-Specification.md`.

The builder `github_source_builder.py` reads **each** original GitHub blob at the pinned SHA and validates Git object SHA/size. `rebuild_full_source.py` merges the new source into that exact project, preserves unmodified files and applies build metadata and null callback preservation. It runs Gradle and produces the full-source ZIP only in a network-enabled environment with GitHub read authorization and Gradle dependency resolution. Neither script uploads to GitHub.

In a network-enabled authenticated environment, the one-shot command is:

```bash
python3 rebuild_full_source.py --fetch-individual-blobs --output PDD-0.3.0realFix-full-source.zip
```

Use `GITHUB_TOKEN` if needed for GitHub API read quotas. This is an executable fallback, not proof that the full archive was produced here. Do not execute Apply before verifying the output and official build. Independent local checks:

```bash
bash run-support-checks.sh
python3 aux-typecheck.py
python3 verify_apply_zip.py PDD-0.3.0realFix-full-source.zip
```

Current evidence and precisely scoped gaps: `docs/verification-0.3.0realFix-integration.md`.

