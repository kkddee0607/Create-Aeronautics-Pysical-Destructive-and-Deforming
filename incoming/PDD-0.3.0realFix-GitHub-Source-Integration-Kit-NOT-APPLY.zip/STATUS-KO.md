# PDD 0.3.0realFix 소스 재구성 상태

## 기준
- GitHub `main` 최신 확인 SHA: `55972847736adad106d4b883f6b943b6217a644a` (2026-10-31 23:08:56 UTC)
- 부모: 기존 GitHub moreRog 전체 소스 (135 트리 항목)
- 설계: IDS 1.0.5-A
- 이 파일은 **전체 소스 ZIP이 아닙니다.** 이전 실패한 Apply 입력을 대체할 배포 ZIP으로 업로드하면 안 됩니다.

## 현재 구현
- Java 21 독립 코어: `GameImpactCredit`, `GameImpactDispatch`, `NativeEffectGroups`, `OwnerLocalTargetCandidates`.
- Sable의 `null` 콜백 보존 패치.
- JUnit 소스 1개와 Java 실행형 픽스처 4개.
- 실험용 재구성 도구는 이미 체크아웃된 GitHub 저장소에 정확한 루트 구조가 있는지 확인하고, 소스를 복사·병합하며, `clean test`·`build` 실행이 성공한 경우에만 ZIP을 만듭니다.

## 현재 검증
- Java 21 실행형 보조 검사: PASS 99개 (60+10+13+16).
- GitHub의 프로젝트 원본 전체 소스: connector로 트리와 일부 파일 읽음. **실행 컨테이너로 원본 ZIP 복원 실패.**
- 실제 PDD `compileJava`, `compileTestJava`, JUnit, `clean test`, `build`: **NOT RUN**.
- GitHub Actions, 인게임: **NOT RUN**.
- 현재 결과는 전체 구현이 아닙니다. 기존 `PhysicalDestroyDeform`의 구형 에피소드 계산 경로는 재구성 도구에서 제거하지 못했습니다.

## 왜 Apply용 ZIP을 제공하지 않았는가
1. GitHub 파일 트리 API는 파일명을 알 수 있지만, Gradle 프로젝트의 모든 실제 파일 바이트를 로컬 컨테이너로 내려받는 git/archive 네트워크 경로는 차단됐습니다.
2. Library의 `PDD-0.3.0-IDS-1.0.3-moreRog-full-source.zip` materialize는 `Project file does not have an authorized raw-byte materialization path`로 실패했습니다.
3. 기존 artifact ZIP에는 빌드 JAR 하나뿐이며 원본 전체 소스가 없습니다.
4. 누락된 Gradle wrapper/JUnit/workflow를 빈 스텁으로 대체하여 Apply 계약을 통과시키는 것은 기존 동작을 파괴하므로 허용하지 않습니다.

## 수동 사용(배포가 아닌 재구성 실험)
GitHub Codespaces에서 저장소를 직접 체크아웃한 뒤 이 키트의 `rebuild_full_source.py`를 사용해 재구성할 수 있습니다. 그러나 원본 live episode 루프 교체가 빠져 있으므로 생성된 ZIP도 **PDD 0.3.0realFix 완성본이 아닙니다.** 원본 전체 소스 ZIP을 채팅 파일로 다시 첨부하면 로컬에서 직접 통합하여 공식 Gradle 검증까지 수행할 수 있습니다.
