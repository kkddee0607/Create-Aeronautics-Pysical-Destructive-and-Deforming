# PDD 0.3.0realFix — 1.0.5-A implementation & verification ledger

## Baseline

- Repository: `kkddee0607/Create-Aeronautics-Pysical-Destructive-and-Deforming`
- Pinned `main`: `55972847736adad106d4b883f6b943b6217a644a` (2026-10-31T23:08:56Z)
- Untruncated tree: 135 entries; 109 files, including 36 production Java files, 27 original JUnit test classes (108 `@Test` declarations), four GitHub workflows and protected Gradle Wrapper.
- Target document: PDD integrated design 1.0.5-A §21–§23.
- Binary evidence: Sable NeoForge 1.21.1-2.0.6 uploaded JAR; `ServerSubLevel.boundingBox():BoundingBox3dc` confirmed, Companion 1.6.0 `BoundingBox3dc.minX/minY/minZ/maxX/maxY/maxZ()` confirmed by actual `javap`. Existing `clearCollisions(J)[D` and 15-double effect feed are read-only.

## Source changes for realFix reconstruction

- `PhysicalDestroyDeform.java`: **entire live moreRog approval pipeline replaced**, not just version. One drain of Sable callback/native events and PRE snapshots on server tick; main calls new `RealFixRuntimeBridge`, not `ImpactLiveAudit.evaluate` or `NativePlotDirection.evaluate`. Server-stopped state cleanup; worldMutation=OFF.
- `collision/RealFixRuntimeBridge.java`: bounded native event grouping by dimension/tick/body IDs, original callback BlockState target evidence, generation-qualified stable owner keys, actual Sable 3D bounding boxes, two-frame *positive* separation warmup, independent gap-closing check, raw-force bounded game budget. Only owner-audited R1 targets can authorize Q; R2/R3 geometry remains uncalibrated. R4 bounded world-boundary candidates are now actually probed (≤32 per owner, ≤1024 checks/tick), logged as PROVISIONAL_ONLY, and never credited without game ground truth. Null/ambiguous inputs Q=0. Gives structured `PDD-OBS`, `PDD-TARGET`, `PDD-EPISODE`, summary log output.
- `collision/RealFixBoundsEvidence.java`: world-space 3D AABB gap and threshold. **AABB intersection is not contact evidence**. Default gap threshold 0.25, approach delta 1/32.
- `collision/RealFixBoundaryCandidates.java`: bounded R4 world-cell candidate list only; no uncalibrated source is promoted to authoritative hit.
- `collision/GameImpactCredit.java`: one-credit state machine with configurable `DEV_PROVISIONAL` settings: `forceEnter=2`, `forceFloor=2`, `forceGain=.25`, `maxGroupQ=64`, `separatedFrames=2`. Explicitly no silence==separation. Two-sided allocation 0.5/0.5 and 0.5 reserved when one side unknown.
- `collision/NativeEffectGroups.java`: Sable 15 double record grouping; group max force, never pointwise sum; bounded source intake 2048.
- `mixin/SableUniversalCallbackMixin.java`: leaves null factory callback unchanged; wraps only original non-null callbacks, exactly-once original delegation preserved.
- `diagnostics/NativeCollisionTelemetry.java`: always-on read-only observation within original queue bound regardless of debug verbosity; Sable's array reference preserved by unchanged `RapierCollisionTelemetryMixin`.
- Existing 27 JUnit classes are retained unchanged in the reconstruction path. New `GameImpactCreditTest.java`, `RealFixBoundsEvidenceTest.java`, and `RealFixBoundaryCandidatesTest.java` are added.
- `build.gradle` and `neoforge.mods.toml` only modify version metadata. Java 21, Gradle Wrapper 8.10.2, NeoForge 21.1.228, JUnit 5.11.4, Sable 2.0.6 and all workflow YAMLs remain unmodified. `docs/PDD-1.0.5-Integrated-Design-Specification.md` is added.

## Evidence vs limitations

| Check | Status |
|---|---|
| GitHub full-tree/109 file per-file source audit | PASS remote inspection |
| Sable JAR `boundingBox()` / Companion accessor signatures | PASS binary javap inspection |
| 115 independent Java 21 credit, grouping, target, AABB and R4-boundary assertions | PASS auxiliary (not JUnit) |
| `RealFixRuntimeBridge` and replacement `PhysicalDestroyDeform` Java 21 type-check with **test-only Minecraft/NeoForge stand-ins** | PASS auxiliary (not real classpath) |
| Exact restore of all 109 GitHub blobs to this restricted runtime | FAILED: GitHub connector reads, local container GitHub DNS unavailable; cannot claim whole-project reconstruction |
| Actual `compileJava`, `compileTestJava`, resource processing | NOT RUN |
| Official `./gradlew clean test --no-daemon` | NOT RUN |
| Official `./gradlew build --no-daemon` | NOT RUN |
| GitHub Actions Apply, Build, Callback Contract against new realFix | NOT RUN |
| In-game actual block IDs, Plot↔World and Plot↔Plot target coverage | NOT RUN |
| R2/R3 collider/pose calibration, R4 unique target in-game proof | R4 shadow candidate enumeration implemented; authoritative verification and G-TARGET-01 incomplete |
| Complete original-source Apply ZIP in this runtime | NOT GENERATED |

**Release status: IMPLEMENTATION CANDIDATE / NOT FULLY IMPLEMENTED / BUILD UNVERIFIED.** Do not upload the accompanying source kit ZIP to `incoming/`. A full-source ZIP produced by `rebuild_full_source.py --fetch-individual-blobs` must include all 109 SHA-verified originals and a Gradle project root; the generated ZIP must then be built and game-tested. The script never uploads to GitHub.

## Two game sessions once a Gradle build actually passes

### Session 1: World↔Plot, original callbacks, separation/reimpact

1. Install the built realFix JAR (single PDD version) with specified 1.21.1/Sable 2.0.6/Create 6.0.10/Aeronautics 1.3.2 environment.
2. Use a Sable physical Plot of stone, approach a static stone wall or block, move it away to obtain at least two full separated ticks, then drive into the wall again. Test special Belt/Fragile callback separately using a PDD-off control if available.
3. Expect `[PDD-OBS] source=POST_EFFECT`, `[PDD-TARGET] targetA/B`, and `[PDD-EPISODE] state=... reason=... Q=... worldMutation=OFF`. First-ever unknown contact may legitimately yield `INITIAL_CONTACT_UNKNOWN` and Q=0; after verified separation and renewed approach, a verified source/target may give Q>0. A missing verified world target is **G-TARGET coverage failure**, not build failure and not a fabricated approval. Verify Belt/Fragile original behavior unchanged.

### Session 2: Plot↔Plot, rotation, resting contacts, high-load source

1. Assemble two independent Sable Plot owners, rotate one 90° and collide; then hold both at rest for ~20 ticks, separate for >=2 physics observations, and collide again. Include rotation-only impact and multiple simultaneous block contacts.
2. Expect **one** Q per pair/episode at most, non-negative bounded Q, canonical UUID ownership, peak force not sum of point records, resting/sliding not repeatedly credited. If exact target/collider frame cannot be validated, expect `TARGET_UNVERIFIED` and Q=0 rather than false-positive damage. Check `nativeDropped=0`, `nativeMalformed=0`, `callbackDropped=0`, crash=0, `worldMutation=OFF`.

**PASS** only with correct actual local block IDs, target evidence, true reimpact and original Sable behavior; **FAIL** if wrong owner, repeated Q at rest, original callback change, unexplained crash or mutation; **INCONCLUSIVE** if source events absent. The release remains unverified until these sessions and official Gradle + Actions pass.
