package com.physicaldestroydeform.collision;

import static com.physicaldestroydeform.collision.RealFixBoundsEvidence.*;

public final class RealFixBoundsEvidenceFixture {
    private static int checked;
    private static void yes(boolean b) {checked++;if(!b)throw new AssertionError("check #"+checked);}
    private static void near(double expected,double actual) {
        checked++;if(Math.abs(expected-actual)>1e-9)throw new AssertionError("expected "+expected+" got "+actual);
    }
    public static void main(String... args) {
        Box zero=Box.block(0,0,0),far=Box.block(3,0,0),near=Box.block(2,0,0);
        yes(far.separatedFrom(zero));
        yes(near.separatedFrom(zero));
        yes(!zero.separatedFrom(Box.block(1,0,0)));
        yes(!zero.separatedFrom(zero));
        near(2,zero.gap(far));
        near(0,zero.gap(zero));
        yes(approaching(zero,far,zero,near));
        yes(!approaching(zero,near,zero,far));
        yes(!approaching(null,far,zero,near));
        try {new Box(1,1,1,0,2,2);throw new AssertionError("bad bbox accepted");}
        catch(IllegalArgumentException expected) {checked++;}
        try {new Box(0,0,0,Double.POSITIVE_INFINITY,2,2);throw new AssertionError("infinite bbox accepted");}
        catch(IllegalArgumentException expected) {checked++;}
        System.out.println("RealFixBoundsEvidenceFixture PASS count="+checked);
    }
}
