package com.physicaldestroydeform.collision;

import com.physicaldestroydeform.collision.RealFixBoundsEvidence.Box;
public final class RealFixBoundaryCandidatesFixture {
    private static int n;
    private static void ok(boolean v){n++;if(!v)throw new AssertionError("case #"+n);}
    public static void main(String... args){
        var p=RealFixBoundaryCandidates.nearOverlap(new Box(0.1,10.1,0.1,0.9,10.9,0.9),1024);
        ok(p.blocks().size()==1);
        ok(p.reason()==RealFixBoundaryCandidates.Reason.CANDIDATES);
        ok(RealFixBoundaryCandidates.nearOverlap(null,100).blocks().isEmpty());
        ok(RealFixBoundaryCandidates.nearOverlap(new Box(0,0,0,80,80,80),1024).reason()==RealFixBoundaryCandidates.Reason.TOO_BROAD);
        ok(RealFixBoundaryCandidates.nearOverlap(new Box(0,0,0,1,1,1),0).reason()==RealFixBoundaryCandidates.Reason.TOO_BROAD);
        System.out.println("RealFixBoundaryCandidatesFixture PASS count="+n);
    }
}
