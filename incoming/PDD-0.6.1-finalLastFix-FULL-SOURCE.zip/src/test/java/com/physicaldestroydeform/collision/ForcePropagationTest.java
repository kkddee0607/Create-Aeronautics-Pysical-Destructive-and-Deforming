package com.physicaldestroydeform.collision;

import com.physicaldestroydeform.DamageModel;
import com.physicaldestroydeform.MaterialProperties;
import com.physicaldestroydeform.material.MaterialPlanner;
import org.junit.jupiter.api.Test;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

/** 0.4.0 colFix: F-first propagation on either owner-local lattice. */
class ForcePropagationTest {
    private static final String WORLD="WORLD:minecraft:overworld";
    private static final String PLOT="PLOT:5069c055-4ebd-415c-b205-a6715b83156d";
    private static final GameImpactCredit.Settings FORCE=GameImpactCredit.Settings.provisional();
    private static final DamageModel.Settings DAMAGE=DamageModel.Settings.defaults();
    private static GameImpactCredit.Target at(String owner,int x,int y,int z) {
        return new GameImpactCredit.Target(owner,x+","+y+","+z,"minecraft:stone|Block{minecraft:stone}");
    }
    private static MaterialProperties material(int e) {return new MaterialProperties(40,100,20,e,false);}
    @Test void weightedSeedsRetainIndividualContactBudget() {
        var a=at(WORLD,0,0,0);var b=at(WORLD,10,0,0);
        var r=ForcePropagation.planTargets(WORLD,java.util.Map.of(a,15d,b,50d),graph(Set.of()),
                t->material(0),FORCE,DAMAGE,ForcePropagation.Orientation.unknown(),null);
        assertEquals(65,r.inputF(),1e-9);
        assertEquals(15,r.shares().stream().filter(s->s.target().equals(a)).findFirst().orElseThrow().allocatedF(),1e-9);
        assertEquals(50,r.shares().stream().filter(s->s.target().equals(b)).findFirst().orElseThrow().allocatedF(),1e-9);
    }
    @Test void weightedSeedsRejectNonfiniteForce() {
        assertThrows(IllegalArgumentException.class,()->ForcePropagation.planTargets(WORLD,
                java.util.Map.of(at(WORLD,0,0,0),Double.NaN),graph(Set.of()),t->material(0),FORCE,DAMAGE,
                ForcePropagation.Orientation.unknown(),null));
    }
    @Test void verifiedCrossOwnerLineConservesOriginalBudgetAndDoesNotReenter() {
        var a=at(PLOT,0,0,0);var b=at(PLOT,1,0,0);var c=at(PLOT,2,0,0);
        var d=at(WORLD,100,0,0);var e=at(WORLD,101,0,0);
        var normal=new ForcePropagation.Orientation(new FrameMath.Vec(1,0,0),"TEST");
        var ctx=new ForcePropagation.CrossOwnerContext() {
            public java.util.Map<String,GameImpactCredit.Owner> owners(){return java.util.Map.of(PLOT,new GameImpactCredit.Owner(PLOT,1),WORLD,new GameImpactCredit.Owner(WORLD,1));}
            public java.util.List<ForcePropagation.CrossEdge> edges(GameImpactCredit.Target from,ForcePropagation.Orientation inward){
                return from.equals(c)?List.of(new ForcePropagation.CrossEdge(d,normal,1)):from.equals(d)?List.of(new ForcePropagation.CrossEdge(c,normal,1)):List.of();
            }
        };
        var r=ForcePropagation.planTargets(PLOT,java.util.Map.of(a,100d),graph(Set.of(PLOT+":0,0,0",PLOT+":1,0,0",PLOT+":2,0,0",WORLD+":100,0,0",WORLD+":101,0,0")),t->material(0),FORCE,DAMAGE,normal,null,ctx);
        assertEquals(List.of(50d,25d,12.5,6.25,6.25),r.shares().stream().map(ForcePropagation.Share::allocatedF).toList());
        assertEquals(100,r.assignedF(),1e-9);
        assertEquals(5,r.shares().stream().map(ForcePropagation.Share::target).distinct().count());
    }
    @Test void missingContactNeverCreatesForeignTarget(){
        var root=at(PLOT,0,0,0);
        var normal=new ForcePropagation.Orientation(new FrameMath.Vec(1,0,0),"TEST");
        var ctx=new ForcePropagation.CrossOwnerContext(){
            public java.util.Map<String,GameImpactCredit.Owner> owners(){return java.util.Map.of();}
            public List<ForcePropagation.CrossEdge> edges(GameImpactCredit.Target from,ForcePropagation.Orientation inward){return List.of();}
        };
        var r=ForcePropagation.planTargets(PLOT,java.util.Map.of(root,100d),graph(Set.of(WORLD+":0,0,0")),t->material(0),FORCE,DAMAGE,normal,null,ctx);
        assertEquals(1,r.shares().size());assertEquals(root,r.shares().getFirst().target());assertEquals(100,r.assignedF(),1e-9);
    }
    @Test void admittedPathThreeOwnersConservesF(){
        String p2="PLOT:6069c055-4ebd-415c-b205-a6715b83156d";
        var a=at(PLOT,0,0,0);var b=at(PLOT,1,0,0);var c=at(p2,100,0,0);
        var d=at(p2,101,0,0);var e=at(WORLD,200,0,0);
        var normal=new ForcePropagation.Orientation(new FrameMath.Vec(1,0,0),"TEST");
        var ctx=new ForcePropagation.CrossOwnerContext(){
            public java.util.Map<String,GameImpactCredit.Owner> owners(){return java.util.Map.of(
                    PLOT,new GameImpactCredit.Owner(PLOT,1),p2,new GameImpactCredit.Owner(p2,1),WORLD,new GameImpactCredit.Owner(WORLD,1));}
            public List<ForcePropagation.CrossEdge> edges(GameImpactCredit.Target from,ForcePropagation.Orientation inward){
                return from.equals(b)?List.of(new ForcePropagation.CrossEdge(c,normal,1)):
                        from.equals(d)?List.of(new ForcePropagation.CrossEdge(e,normal,1)):List.of();
            }
        };
        var r=ForcePropagation.planTargets(PLOT,java.util.Map.of(a,100d),graph(Set.of(PLOT+":0,0,0",PLOT+":1,0,0",p2+":100,0,0",p2+":101,0,0",WORLD+":200,0,0")),t->material(0),FORCE,DAMAGE,normal,null,ctx);
        assertEquals(List.of(50d,25d,12.5,6.25,6.25),r.shares().stream().map(ForcePropagation.Share::allocatedF).toList());
        assertEquals(100,r.assignedF(),1e-9);assertEquals(2,r.audit().crossEdges());
        assertEquals(3,r.shares().stream().map(s->s.target().ownerKey()).distinct().count());
    }
    @Test void crossOwnerDiamondMergesEqualDepthOnlyOnce(){
        var a=at(PLOT,0,0,0);var b=at(PLOT,0,0,1);var c=at(WORLD,50,0,0);
        var normal=new ForcePropagation.Orientation(new FrameMath.Vec(1,0,0),"TEST");
        var ctx=new ForcePropagation.CrossOwnerContext(){
            public java.util.Map<String,GameImpactCredit.Owner> owners(){return java.util.Map.of(PLOT,new GameImpactCredit.Owner(PLOT,1),WORLD,new GameImpactCredit.Owner(WORLD,1));}
            public List<ForcePropagation.CrossEdge> edges(GameImpactCredit.Target from,ForcePropagation.Orientation inward){return from.equals(a)||from.equals(b)?List.of(new ForcePropagation.CrossEdge(c,normal,1)):List.of();}
        };
        var r=ForcePropagation.planTargets(PLOT,java.util.Map.of(a,50d,b,50d),graph(Set.of()),t->material(0),FORCE,DAMAGE,normal,null,ctx);
        assertEquals(3,r.shares().size());assertEquals(1,r.audit().mergedNodes());
        assertEquals(50,r.shares().stream().filter(s->s.target().equals(c)).findFirst().orElseThrow().allocatedF(),1e-9);
        assertEquals(100,r.assignedF(),1e-9);
    }
    @Test void crossBoundaryDistinguishesInternalAndContactElasticity(){
        var a=at(PLOT,0,0,0);var b=at(WORLD,100,0,0);
        var normal=new ForcePropagation.Orientation(new FrameMath.Vec(1,0,0),"TEST");
        var ctx=new ForcePropagation.CrossOwnerContext(){
            public java.util.Map<String,GameImpactCredit.Owner> owners(){return java.util.Map.of(PLOT,new GameImpactCredit.Owner(PLOT,1),WORLD,new GameImpactCredit.Owner(WORLD,1));}
            public List<ForcePropagation.CrossEdge> edges(GameImpactCredit.Target from,ForcePropagation.Orientation inward){return from.equals(a)?List.of(new ForcePropagation.CrossEdge(b,normal,1)):List.of();}
        };
        var r=ForcePropagation.planTargets(PLOT,java.util.Map.of(a,100d),graph(Set.of()),t->material(t.equals(a)?100:0),FORCE,DAMAGE,normal,null,ctx);
        assertEquals(42.5,r.dampedF(),1e-9);assertEquals(2.55,r.contactDampedF(),1e-9);
        assertEquals(54.95,r.assignedF(),1e-9);assertEquals(100,r.assignedF()+r.dampedF()+r.contactDampedF(),1e-9);
    }
    private static ForcePropagation.NeighborReader graph(Set<String> occupied) {
        return (from,x,y,z)->occupied.contains(from.ownerKey()+":"+x+","+y+","+z)
                ?ForcePropagation.Probe.present(at(from.ownerKey(),x,y,z))
                :ForcePropagation.Probe.empty();
    }
    private static ForcePropagation.Result line(String owner,int count) {
        var occupied=new HashSet<String>();
        for(int i=0;i<count;i++)occupied.add(owner+":"+i+",0,0");
        return ForcePropagation.plan(owner,List.of(at(owner,0,0,0)),100,graph(occupied),
                fp->material(0),FORCE,DAMAGE);
    }
    @Test void fiveBlockPathFHalvesAndTerminalTakesRemainderForWorldAndPlot() {
        for(String owner:List.of(WORLD,PLOT)) {
            var r=line(owner,5);
            assertEquals("VERIFIED_TERMINAL",r.endReason());
            assertEquals(5,r.shares().size());
            double[] f={50,25,12.5,6.25,6.25};
            // k=0.1 per-node F-to-Q conversion after the existing terminal F accounting.
            double[] q={4.8,2.3,1.05,.425,.425};
            for(int i=0;i<5;i++) {
                assertEquals(f[i],r.shares().get(i).allocatedF(),1e-9);
                assertEquals(q[i],r.shares().get(i).finalQ(),1e-9);
            }
            assertEquals(100,r.assignedF(),1e-9);
            assertEquals(0,r.unresolvedF(),1e-9);
            assertEquals(0,r.dampedF(),1e-9);
        }
    }
    @Test void singleAndTwoBlocksRespectProvenTerminal() {
        assertEquals(100,line(WORLD,1).shares().getFirst().allocatedF(),1e-9);
        var two=line(PLOT,2);
        assertEquals(50,two.shares().getFirst().allocatedF(),1e-9);
        assertEquals(50,two.shares().getLast().allocatedF(),1e-9);
    }
    @Test void middleElasticNodeReducesUpstreamQAndDownstreamForce() {
        var occupied=new HashSet<String>();
        for(int i=0;i<5;i++)occupied.add(WORLD+":"+i+",0,0");
        var r=ForcePropagation.plan(WORLD,List.of(at(WORLD,0,0,0)),100,graph(occupied),
                fp->material(0),FORCE,DAMAGE);
        // The shape/fingerprint is the material identity, not the coordinate; use distinct state evidence.
        var b=new ForcePropagation.NeighborReader() {
            public ForcePropagation.Probe read(GameImpactCredit.Target from,int x,int y,int z) {
                if(x<0||x>4||y!=0||z!=0)return ForcePropagation.Probe.empty();
                var t=new GameImpactCredit.Target(WORLD,x+",0,0",x==1?"minecraft:wool|elastic":"minecraft:stone|solid");
                return ForcePropagation.Probe.present(t);
            }
        };
        var seed=new GameImpactCredit.Target(WORLD,"0,0,0","minecraft:stone|solid");
        var elastic=ForcePropagation.plan(WORLD,List.of(seed),100,b,
                fp->material(fp.contains("elastic")?40:0),FORCE,DAMAGE);
        assertTrue(elastic.shares().getFirst().finalQ()<r.shares().getFirst().finalQ());
        assertTrue(elastic.shares().get(2).allocatedF()<r.shares().get(2).allocatedF());
        assertTrue(elastic.dampedQ()>0 && elastic.dampedF()>0);
        assertEquals(100,elastic.assignedF()+elastic.dampedF()+elastic.unresolvedF(),1e-8);
    }
    @Test void simultaneousContactsReceiveEqualSharesAndNeverRevisitDiamond() {
        var occupied=Set.of(WORLD+":0,0,0",WORLD+":1,0,0",WORLD+":0,0,1",WORLD+":1,0,1");
        var r=ForcePropagation.plan(WORLD,List.of(at(WORLD,1,0,0),at(WORLD,0,0,0)),100,
                graph(occupied),fp->material(0),FORCE,DAMAGE);
        assertEquals(4,r.shares().size());
        assertEquals(25,r.shares().get(0).allocatedF(),1e-9);
        assertEquals(25,r.shares().get(1).allocatedF(),1e-9);
        assertEquals(25,r.shares().get(2).allocatedF(),1e-9);
        assertEquals(25,r.shares().get(3).allocatedF(),1e-9);
        assertEquals(4L,r.shares().stream().map(t->t.target().localBlock()).distinct().count());
        assertEquals(100,r.assignedF(),1e-9);
    }
    @Test void unknownNeighborCannotPretendToBeLastBlock() {
        var r=ForcePropagation.plan(WORLD,List.of(at(WORLD,0,0,0)),100,
                (from,x,y,z)->x==1?ForcePropagation.Probe.unknown():ForcePropagation.Probe.empty(),
                fp->material(0),FORCE,DAMAGE);
        assertEquals("UNVERIFIED_BOUNDARY",r.endReason());
        assertEquals(50,r.assignedF(),1e-9);
        assertEquals(50,r.unresolvedF(),1e-9);
    }
    @Test void fingerprintConflictRejectsWholePlan() {
        assertThrows(IllegalArgumentException.class,()->ForcePropagation.plan(WORLD,
                List.of(at(WORLD,0,0,0),new GameImpactCredit.Target(WORLD,"0,0,0","changed")),
                100,graph(Set.of()),fp->material(0),FORCE,DAMAGE));
    }
    @Test void elasticHundredNeverCreatesNegativeOrInfiniteTransfers() {
        var provider=new ForcePropagation.NeighborReader() {
            public ForcePropagation.Probe read(GameImpactCredit.Target from,int x,int y,int z) {
                if(x<0||x>3||y!=0||z!=0)return ForcePropagation.Probe.empty();
                return ForcePropagation.Probe.present(new GameImpactCredit.Target(WORLD,x+",0,0",
                        x==1?"minecraft:wool|elastic":"minecraft:stone|solid"));
            }
        };
        var r=ForcePropagation.plan(WORLD,List.of(new GameImpactCredit.Target(WORLD,"0,0,0",
                "minecraft:stone|solid")),100,provider,
                fp->material(fp.contains("elastic")?100:0),FORCE,DAMAGE);
        assertEquals("VERIFIED_TERMINAL",r.endReason());
        assertEquals(4,r.shares().size());
        assertTrue(r.shares().getFirst().finalQ()>0);
        assertTrue(r.dampedF()>0 && r.dampedQ()>0);
        assertTrue(r.shares().stream().allMatch(t->Double.isFinite(t.finalQ())&&t.finalQ()>=0));
        assertEquals(100,r.assignedF()+r.dampedF()+r.unresolvedF(),1e-8);
    }
    @Test void boundedGraphNeverPassesLeftoverForceToArbitraryLastNode() {
        var occupied=new HashSet<String>();
        // A dense cube reaches the node cap before the minimum-F cutoff.
        // A corner-seeded plane spreads too slowly and can stop on the F floor first.
        int width=(int)Math.ceil(Math.cbrt(ForcePropagation.MAX_NODES_PER_SIDE))+1;
        for(int x=0;x<width;x++)for(int y=0;y<width;y++)for(int z=0;z<width;z++)
            occupied.add(PLOT+":"+x+","+y+","+z);
        var r=ForcePropagation.plan(PLOT,List.of(at(PLOT,0,0,0)),1e70,graph(occupied),
                fp->material(0),FORCE,DAMAGE);
        assertEquals(ForcePropagation.MAX_NODES_PER_SIDE,r.shares().size());
        assertEquals("UNVERIFIED_BOUNDARY",r.endReason());
        assertTrue(r.unresolvedF()>0);
        assertEquals(1e70,r.assignedF()+r.dampedF()+r.unresolvedF(),1e55);
    }
    @Test void twoHundredConnectedBlocksNowReachVerifiedTerminalUnderExpandedBudget() {
        var occupied=new HashSet<String>();
        for(int i=0;i<200;i++)occupied.add(PLOT+":"+i+",0,0");
        var r=ForcePropagation.plan(PLOT,List.of(at(PLOT,0,0,0)),1e70,graph(occupied),
                fp->material(0),FORCE,DAMAGE);
        assertEquals(200,r.shares().size());
        assertEquals("VERIFIED_TERMINAL",r.endReason());
        assertEquals(0,r.unresolvedF(),0);
        assertEquals(1e70,r.assignedF()+r.dampedF()+r.unresolvedF(),1e55);
    }
    @Test void sourceEnvelopeCapsTotalHighForceAfterPerBlockConversion() {
        var pair=GameImpactCredit.Pair.canonical("run","minecraft:overworld",
                new GameImpactCredit.Owner(WORLD,1),new GameImpactCredit.Owner(PLOT,1));
        var q=FORCE.candidate(1e10);
        var d=new GameImpactCredit.Decision(GameImpactCredit.Phase.ACTIVE,
                GameImpactCredit.Reason.APPROVED,1e10,q,new GameImpactCredit.Allocation(q/2,q/2,0),
                1,1,10,10,GameImpactCredit.POLICY_REVISION);
        var r=new ContactCreditLedger().issuePropagated(pair,d,
                ContactCreditLedger.Source.SABLE_POST_EFFECT,
                List.of(new ContactCreditLedger.Region(at(pair.a().stableKey(),0,0,0),
                        at(pair.b().stableKey(),0,0,0))),graph(Set.of()),fp->material(0),FORCE,DAMAGE);
        assertTrue(r.credited());
        assertEquals(q,r.allocatedA()+r.allocatedB(),1e-9);
        assertEquals(q,r.accounted(),1e-9);
    }

    @Test void integratedLedgerSeparatesWorldAndPlotAndDoesNotDoubleDiscountElasticity() {
        var pair=GameImpactCredit.Pair.canonical("run","minecraft:overworld",
                new GameImpactCredit.Owner(WORLD,1),new GameImpactCredit.Owner(PLOT,1));
        double q=FORCE.candidate(100);
        var d=new GameImpactCredit.Decision(GameImpactCredit.Phase.ACTIVE,
                GameImpactCredit.Reason.APPROVED,100,q,new GameImpactCredit.Allocation(q/2,q/2,0),
                1,1,10,10,GameImpactCredit.POLICY_REVISION);
        var evidence=List.of(new ContactCreditLedger.Region(at(pair.a().stableKey(),0,0,0),
                at(pair.b().stableKey(),0,0,0)));
        var ledger=new ContactCreditLedger();
        var r=ledger.issuePropagated(pair,d,ContactCreditLedger.Source.SABLE_POST_EFFECT,evidence,
                graph(Set.of(WORLD+":0,0,0",PLOT+":0,0,0")),fp->material(60),FORCE,DAMAGE);
        assertTrue(r.credited());assertTrue(r.propagated());
        assertEquals(1,r.a().size());assertEquals(1,r.b().size());
        assertEquals(pair.a().stableKey(),r.a().getFirst().target().ownerKey());
        assertEquals(pair.b().stableKey(),r.b().getFirst().target().ownerKey());
        assertEquals(q,r.accounted(),1e-9);
        var material=MaterialPlanner.plan(r,1,fp->material(60),DAMAGE);
        // colFix2 separates neighbor damping from the material's OWN elasticity.
        assertTrue(material.plans().getFirst().plan().activeQ()<r.a().getFirst().q());
        assertEquals(r.a().getFirst().q(),material.plans().getFirst().plan().accountedQ(),1e-8);
        assertEquals(ContactCreditLedger.Status.DUPLICATE_CAUSE,
                ledger.issuePropagated(pair,d,ContactCreditLedger.Source.SABLE_POST_EFFECT,evidence,
                        graph(Set.of()),fp->material(60),FORCE,DAMAGE).status());
    }
    @Test void rogTraceDoesNotChangeForceOrQAccounting(){
        var seed=at(WORLD,0,0,0);
        var expected=ForcePropagation.planTargets(WORLD,java.util.Map.of(seed,100d),graph(Set.of()),
                t->material(40),FORCE,DAMAGE,ForcePropagation.Orientation.unknown(),null);
        com.physicaldestroydeform.diagnostics.RogTrace.start();
        try{
            com.physicaldestroydeform.diagnostics.RogTrace.begin(1);
            assertEquals(expected,ForcePropagation.planTargets(WORLD,java.util.Map.of(seed,100d),graph(Set.of()),
                    t->material(40),FORCE,DAMAGE,ForcePropagation.Orientation.unknown(),null));
        }finally{com.physicaldestroydeform.diagnostics.RogTrace.stop();}
    }
}
