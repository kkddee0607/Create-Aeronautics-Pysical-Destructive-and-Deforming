package com.physicaldestroydeform.world;

import java.util.Arrays;

/** Bounded timings only. Neither admission, WAL ordering, nor recovery depends on these samples. */
final class JournalIoMetrics {
    enum Phase { WAL_APPEND, WAL_FORCE, WAL_CREATE, RECEIPT_ENCODE, RECEIPT_INDEX,
        COLD_RECEIPT_READ, SNAPSHOT_BUILD, DURABLE_WRITE, FILE_WRITE, FILE_FORCE,
        MANIFEST_ENCODE, MANIFEST_FILE_WRITE, MANIFEST_FILE_FORCE, MANIFEST_MOVE,
        MANIFEST_DIRECTORY_FORCE, DIRECTORY_FORCE, PUBLISH, CHECKPOINT, CLEANUP_SCAN }
    private static final int WINDOW=128;
    private final long[][] durations=new long[Phase.values().length][WINDOW];
    private final int[] size=new int[Phase.values().length], next=new int[Phase.values().length];
    private final long[] counts=new long[Phase.values().length], max=new long[Phase.values().length];

    private final boolean enabled;
    JournalIoMetrics(){this(true);}
    JournalIoMetrics(boolean enabled){this.enabled=enabled;}
    long now(){return enabled?System.nanoTime():0;}
    synchronized void record(Phase phase,long nanos) {
        if(!enabled||nanos<0)return;
        int i=phase.ordinal();
        durations[i][next[i]]=nanos;next[i]=(next[i]+1)%WINDOW;
        if(size[i]<WINDOW)size[i]++;
        counts[i]++;
        if(nanos>max[i])max[i]=nanos;
    }
    void recordBackgroundCleanup(long nanos){record(Phase.CLEANUP_SCAN,nanos);}
    synchronized String summary() {
        if(!enabled)return "";
        var result=new StringBuilder();
        for(var phase:Phase.values()) {
            int i=phase.ordinal();
            if(counts[i]==0)continue;
            var sorted=Arrays.copyOf(durations[i],size[i]);Arrays.sort(sorted);
            if(result.length()!=0)result.append(' ');
            result.append(phase).append("={count:").append(counts[i])
                    .append(",p95Nanos:").append(sorted[(size[i]*95+99)/100-1])
                    .append(",maxNanos:").append(max[i]).append('}');
        }
        return result.toString();
    }
}
