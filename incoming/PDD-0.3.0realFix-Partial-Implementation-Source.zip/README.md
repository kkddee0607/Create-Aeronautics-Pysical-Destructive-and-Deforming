# PDD 0.3.0realFix — algorithm core work product (NOT the completed mod)

**Status: PARTIAL_IMPLEMENTATION / OFFICIAL_BUILD_NOT_RUN. DO NOT upload this ZIP into the GitHub `incoming/` folder.**

GitHub `main` baseline: `ee5b7cfd8122879570831bdcae2a889be50e3ed6`.
Normative input: PDD IDS 1.0.5-A §§21–23, 26–28. This ZIP is **not** a full PDD project source archive: the existing GitHub sources and tests were not available as a local checkout in this execution environment. The binary `moreRog` JAR is not source code and was not presented as source.

## What this ZIP contains

1. `GameImpactCredit.java` — bounded one-credit policy, real-separation-only rearm, validated-approach gate, game-provisional Q (not physical impulse), two-side accounting and half-reservation, structured source-independent results.
2. `NativeEffectGroups.java` — 15-field native force record validation and per-pair/tick max aggregation (no sum of reported points).
3. `OwnerLocalTargetCandidates.java` — owner-local R1 callback, R2 calibrated collider point, R3 cross-side projection, R4 provisional swept-boundary candidates; loaded-block/owner/fingerprint gates and bounded candidate checks. It **does not invent** the absent collider pose transform.
4. `GameImpactDispatch.java` — input adapter boundary, structured episode logs. It deliberately requires externally validated owner, target and approach evidence.
5. Four `*Fixture.java` programs with executable assertions and `GameImpactCreditTest.java` with nine JUnit 5 test methods for integration into the existing Gradle project.
6. `patches/preserve-null-callback.patch` — an implementation proposal: stop changing the factory's original `null` callback into a PDD nonnull callback. Patch has not been applied to a complete project checkout.
7. Copy of the project design specification for clear algorithm provenance.

## Tested commands

`./run-support-checks.sh` — Java 21 with `javac --release 21 -Xlint:all`; pure-Java fixture execution. It does not invoke NeoForge, Sable, Gradle or JUnit.

## Integration requirements not yet fulfilled

- Integrate `GameImpactDispatch` in the real `PhysicalDestroyDeform.onServerTick`, consuming the existing Sable native feed **after** the solver without changing its return object.
- Implement/validate the real Sable owner-runtime-ID/generation index and collider-relative-to-owner-local transforms. The supplied `TargetCandidates` class only applies to *already calibrated owner-local coordinates*; R4 remains provisional and cannot mint credit without ground truth.
- Provide independently observed separation and verified approach signals. No native-array absence is accepted as a separation signal.
- Preserve original special callback invocation count, return reference, exception behavior and order; apply the null-preservation change and run existing callback regression tests.
- Preserve **all** main/test sources from the actual GitHub `main` branch, wrapper, NeoForge/Java/JUnit versions and the existing GitHub Actions and Apply ZIP contracts.
- Run official `./gradlew clean test --no-daemon`, `./gradlew build --no-daemon`, and later GitHub Actions and two in-game sessions.

## Explicit unverified areas

The source and algorithm fixtures compile/run, but this does **not** demonstrate any successful in-game collision, accurate world/Plot block target, positive game credit in real gameplay, Gradle test/build success or Apply ZIP validity. Nothing in this ZIP changes blocks.

## Proposed in-game test once integrated

**Session A:** a single known Plot block strikes a static stone wall, then remains in contact for 20 ticks, separates for two verified observations, and strikes again. Log `PDD-OBS`, `PDD-TARGET`, `PDD-EPISODE`, `Q`, split allocation and all missing evidence; one group credit after proven recontact, no repeated rest credit. `worldMutation=OFF`.

**Session B:** Plot↔Plot with yaw=90°, multiple simultaneous contact points, rotation-only impact and a static barrier. Confirm actual owner UUID, each owner-local block, paired group Q bounded by 64, no duplicate native-force-point sum, and original Sable callback regressions. Any unvalidated target/approach must be logged with Q=0 rather than silently accepted.
