# 0.3.0realFix evidence ledger — partial implementation

## Fixed baseline

- GitHub repository: `kkddee0607/Create-Aeronautics-Pysical-Destructive-and-Deforming`
- GitHub `main`: `ee5b7cfd8122879570831bdcae2a889be50e3ed6` (read through GitHub connector; full tree 135 entries)
- Existing version: `0.3.0-moreRog` (`build.gradle`)
- Spec: uploaded `PDD-1.0.5-Integrated-Design-Specification.md` (1.0.5-A)
- Sable JAR SHA256: `9c199157843bf953a47dff625fc5bb41c01a90538d35ad18e6996bbcb8a617c2`
- Sable Rapier nested JAR SHA256: `0f0ec5f9a0cdbff937fb36542eb568988f27e6eb7f848cb4df35ad202ced53a7`

## Implemented/verified scope

| Contract | Result | Basis |
|---|---|---|
| 15-double shape, finite IDs/force, invalid records | Implemented / auxiliary assertions PASS | NativeEffectGroups + GameImpactCredit |
| Duplicate native force points -> one pair peak, not sum | Implemented / auxiliary assertions PASS | NativeEffectGroups and late-peak regression |
| Owner-local R1/R2/R3/R4 candidate priority and bounded checks | Policy implemented / auxiliary assertions PASS | OwnerLocalTargetCandidates |
| R4 provisional, ambiguous and unloaded target fail closed | Implemented / auxiliary assertions PASS | OwnerLocalTargetCandidates |
| Explicit separation + verified approach + single group credit | Implemented / auxiliary assertions PASS | GameImpactCredit |
| F=42 -> Q=10, both sides 5 each, one side half reserved | Implemented / auxiliary assertions PASS | GameImpactCredit |
| Original Sable 2.0.6 native Java declarations | `javap` inspected | `Rapier3D.clearCollisions(long):double[]`, `ServerSubLevelContainer.getAllSubLevels()` |
| Existing project origin and source tree | Verified on GitHub connector | main SHA and tree entry count |
| Existing main/test source preservation in generated project | **NOT ACHIEVED** | Local git clone failed due DNS; source ZIP in Project Library could not be materialized |
| Live owner index + verified Java collider-to-owner frame | **NOT IMPLEMENTED** | Needs runtime bridge and gameplay evidence |
| Gameplay force feed connected to new credit engine | **NOT IMPLEMENTED** | No new main entrypoint integration |
| NeoForge compileJava/processResources/jar | **NOT RUN** | Official Gradle checkout not locally available |
| compileTestJava and all existing/new JUnit | **NOT RUN** | Official Gradle checkout/test runtime missing |
| `./gradlew clean test --no-daemon` | **NOT RUN** | Official wrapper/project missing in checkout |
| `./gradlew build --no-daemon` | **NOT RUN** | Same reason |
| GitHub Actions (Build, Callback, Apply) for realFix | **NOT RUN** | Repo not modified; actions not triggered |
| In-game verification | **NOT RUN** | No built realFix mod JAR |
| Official completed full-source Apply ZIP | **NOT PROVIDED** | Partial package must not be uploaded to incoming |

## Auxiliary verification record

Java 21 `javac --release 21 -Xlint:all` passed (0 compiler errors). Java fixtures `GameImpactCreditFixture` 60 assertions, `NativeEffectGroupsFixture` 10, `GameImpactDispatchFixture` 13, `OwnerLocalTargetCandidatesFixture` 16: **99 total, all passed**. Counts reflect independent fixture checks, not JUnit test cases. Additional 9 JUnit methods are written but **not run**.

## Decision rule

Status is `PARTIAL_IMPLEMENTATION` not `IMPLEMENTATION_COMPLETE`, `BUILD_VERIFIED` or `GAME_VERIFIED`. The resulting ZIP contains useful source and a proposed callback patch, but is intentionally NOT an Apply ZIP and makes no unverified real-game functional claims. Existing GitHub workflows or prior moreRog success do not count as realFix success.
