package com.physicaldestroydeform.collision;

public final class NativeEffectGroupsFixture {
    private static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);}
    public static void main(String[] args) {
        double[] raw = new double[5*15];
        for(int i=0;i<4;i++){
            raw[i*15]=3;raw[i*15+1]=-1;raw[i*15+2]=i+10;
        }
        raw[60]=-1;raw[61]=3;raw[62]=6;
        var batch=NativeEffectGroups.aggregate("minecraft:overworld",1,raw);
        check(!batch.malformedArray(),"valid array");
        check(batch.totalRecords()==5,"source records 5");
        check(batch.groups().size()==1,"canonical pair");
        var group=batch.groups().get(0);
        check(group.forcePeak()==13,"peak not sum");
        check(group.originalRecordCount()==5,"all points accounted");
        check(group.samples().size()==4,"bounded samples");
        check(group.runtimePair().lowId()==-1&&group.runtimePair().highId()==3,"IDs sorted");
        raw[16]=Double.NaN; // second record's ID B
        var malformed=NativeEffectGroups.aggregate("minecraft:overworld",2,raw);
        check(malformed.invalidRecords()==1,"bad ID isolated");
        check(malformed.groups().get(0).originalRecordCount()==4,"remaining points kept");
        check(NativeEffectGroups.aggregate("minecraft:overworld",2,new double[13]).malformedArray(),
                "length must be divisible by 15");
        System.out.println("NativeEffectGroupsFixture PASS count=10");
    }
}
