package com.physicaldestroydeform.collision;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import static com.physicaldestroydeform.collision.GameImpactCredit.*;

/** Standalone assertions for prototype, NOT a replacement for official Gradle/JUnit. */
public final class GameImpactCreditFixture {
    private static int checks;
    private static void check(boolean condition,String reason) {
        checks++;
        if(!condition)throw new AssertionError(reason);
    }
    private static final Owner A = new Owner("PLOT:df68ae77",1);
    private static final Owner B = new Owner("WORLD:minecraft:overworld",1);
    private static final Pair PAIR = Pair.canonical("run-a","minecraft:overworld",A,B);
    private static final Target TA = new Target(A.stableKey(),"10,64,10","minecraft:stone");
    private static final Target TB = new Target(B.stableKey(),"20,64,20","minecraft:stone");
    private static List<ObservedForce> records(double... f) {
        var result=new ArrayList<ObservedForce>();
        for(int i=0;i<f.length;i++) result.add(new ObservedForce(1,-1,f[i],i));
        return result;
    }
    private static Frame event(long tick, List<ObservedForce> records,boolean separated,
                               boolean approach,Target ta,Target tb) {
        return new Frame(PAIR,tick,records,separated,approach,ta,tb);
    }
    private static void fixturePolicy() {
        var settings=Settings.provisional();
        check(settings.candidate(42)==10,"42 -> group 10");
        check(settings.candidate(1.8)==0,"below floor");
        check(settings.candidate(1000)==64,"cap 64");
        check(settings.candidate(Double.NaN)==0,"NaN rejected");
        check(peak(records(42,42,42,42))==42,"duplicate points do not sum");
        check(peak(records(5,8,2))==8,"max not sum");
        check(Pair.canonical("run-a","minecraft:overworld",A,B).equals(
                Pair.canonical("run-a","minecraft:overworld",B,A)),"pair canonical");
    }
    private static void fixtureLifecycle() {
        var ledger=new GameImpactCredit(Settings.provisional());
        // Source first observed in contact: no positive credit without separation history.
        var first=ledger.step(event(1,records(42),false,true,TA,TB));
        check(first.reason()==Reason.INITIAL_CONTACT_UNKNOWN,"initial unknown");
        check(first.issuedQ()==0,"no initial Q");
        check(ledger.step(event(2,List.of(),false,false,TA,TB)).reason()
                ==Reason.UNKNOWN_SEPARATION,"silence does not rearm");
        check(ledger.step(event(3,records(55),false,true,TA,TB)).reason()
                ==Reason.DUPLICATE_EPISODE,"persistent contact no credit");
        check(ledger.step(event(4,List.of(),true,false,TA,TB)).phase()==Phase.COOLING,
                "first proven gap cooling");
        check(ledger.step(event(5,List.of(),true,false,TA,TB)).phase()==Phase.ARMED,
                "two proven gaps armed");
        var second=ledger.step(event(6,records(42,42,42,42),false,true,TA,TB));
        check(second.credited(),"reimpact after gap credited");
        check(second.issuedQ()==10,"Q game=10");
        check(second.allocation().sideA()==5 && second.allocation().sideB()==5,
                "two target each 5");
        check(second.allocation().total()==10,"conservation of game credit");
        for(int tick=7;tick<27;tick++)check(!ledger.step(event(tick,records(42),false,true,TA,TB)).credited(),
                "rest/sliding event duplicate: "+tick);
        check(ledger.step(event(26,records(42),false,true,TA,TB)).reason()==Reason.STALE_FRAME,
                "duplicate/stale tick ignored");
        check(ledger.step(event(27,List.of(),true,false,TA,TB)).phase()==Phase.COOLING,"cooling");
        check(ledger.step(event(28,List.of(),true,false,TA,TB)).phase()==Phase.ARMED,"armed again");
        var one=ledger.step(event(29,records(42),false,true,TA,null));
        check(one.credited(),"single-side verified credit allowed");
        check(one.allocation().sideA()==5 && one.allocation().unused()==5,
                "unknown-side half reserved");
        check(one.allocation().total()==10,"credit conserved with unknown side");
    }
    private static void fixtureNegative() {
        var ledger=new GameImpactCredit(Settings.provisional());
        ledger.step(event(1,List.of(),true,false,TA,TB));
        ledger.step(event(2,List.of(),true,false,TA,TB));
        check(ledger.step(event(3,records(42),false,false,TA,TB)).reason()
                ==Reason.APPROACH_UNVERIFIED,"approach required");
        ledger.step(event(4,List.of(),true,false,TA,TB));
        ledger.step(event(5,List.of(),true,false,TA,TB));
        check(ledger.step(event(6,records(42),false,true,null,null)).reason()
                ==Reason.TARGET_UNVERIFIED,"target required");
        ledger.step(event(7,List.of(),true,false,TA,TB));
        ledger.step(event(8,List.of(),true,false,TA,TB));
        check(ledger.step(event(9,records(1.8),false,true,TA,TB)).reason()
                ==Reason.BELOW_THRESHOLD,"force threshold");
        ledger.clear();check(ledger.activePairs()==0,"clear");
    }
    private static void fixtureParser() {
        double[] array=new double[4*15];
        for(int i=0;i<4;i++){
            array[i*15]=1;array[i*15+1]=-1;array[i*15+2]=42;
        }
        check(GameImpactCredit.parse(array).size()==4,"four point records");
        check(GameImpactCredit.peak(GameImpactCredit.parse(array))==42,"no point sum");
        check(GameImpactCredit.parse(new double[14]).isEmpty(),"bad length");
        var broken=array.clone();broken[0]=Double.NaN;
        check(GameImpactCredit.parse(broken).size()==3,"NaN record skipped");
        broken=array.clone();broken[0]=2e20;
        check(GameImpactCredit.parse(broken).size()==3,"ID overflow skipped");
        broken=array.clone();broken[0]=-1;broken[1]=-1;
        check(GameImpactCredit.parse(broken).size()==3,"two static IDs invalid");
        broken=array.clone();broken[2]=Double.POSITIVE_INFINITY;
        check(GameImpactCredit.parse(broken).size()==3,"infinite force rejected");
        check(GameImpactCredit.parse(null).isEmpty(),"null is malformed");
    }
    private static void fixturePruneAndSafety() {
        var ledger=new GameImpactCredit(new Settings(2,2,.25,64,2,1,3));
        ledger.step(event(1,List.of(),true,false,TA,TB));
        check(ledger.activePairs()==1,"capacity first entry");
        var other=Pair.canonical("run-a","minecraft:overworld",A,new Owner("OTHER",1));
        var second=new Frame(other,1,List.of(),true,false,
                new Target(other.a().stableKey(),"1,2,3","minecraft:stone"),null);
        check(ledger.step(second).reason()==Reason.STATE_CAPACITY_EXCEEDED,"bound state size");
        ledger.prune(5);check(ledger.activePairs()==0,"old state pruned");
        check(ledger.step(second).reason()==Reason.SEPARATION_WARMUP,"reused free slot");
        boolean wrongOwner=false;
        try{new Frame(PAIR,4,records(42),false,true,
                new Target("OTHER","x","stone"),null);}
        catch(IllegalArgumentException expected){wrongOwner=true;}
        check(wrongOwner,"cross-owner rejected");
    }
    public static void main(String[] args) {
        fixturePolicy();fixtureLifecycle();fixtureNegative();fixtureParser();fixturePruneAndSafety();
        System.out.println("PDD-IDS-1.0.5-A supplemental assertions PASS count="+checks);
    }
}
