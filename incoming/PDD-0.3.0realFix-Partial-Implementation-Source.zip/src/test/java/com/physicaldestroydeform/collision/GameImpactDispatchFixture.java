package com.physicaldestroydeform.collision;

import static com.physicaldestroydeform.collision.GameImpactCredit.*;
import java.util.List;

public final class GameImpactDispatchFixture {
    private static int checks;
    private static void check(boolean yes,String label){checks++;if(!yes)throw new AssertionError(label);}
    public static void main(String[] args){
        var a=new Owner("PLOT:001",1);var b=new Owner("WORLD:minecraft:overworld",1);
        var pair=Pair.canonical("run-1","minecraft:overworld",a,b);
        var ta=new Target(pair.a().stableKey(),"100,70,100","minecraft:stone");
        var tb=new Target(pair.b().stableKey(),"10,70,10","minecraft:stone");
        var bridge=new GameImpactDispatch(new GameImpactCredit(Settings.provisional()));
        double[] raw=new double[60];
        for(int i=0;i<4;i++){raw[i*15]=23;raw[i*15+1]=-1;raw[i*15+2]=42;}
        var batch=NativeEffectGroups.aggregate("minecraft:overworld",1,raw);
        check(batch.groups().size()==1,"4 points => 1 group");
        check(bridge.handle(batch,g->null).get(0).logLine().contains("Q=0"),"unknown owner no credit");
        // Feed evidence must originate in an independent, validated Sable geometry reader.
        bridge.engine().step(new Frame(pair,1,List.of(),true,false,ta,tb));
        bridge.engine().step(new Frame(pair,2,List.of(),true,false,ta,tb));
        var t3=NativeEffectGroups.aggregate("minecraft:overworld",3,raw);
        var outcomes=bridge.handle(t3,g->new GameImpactDispatch.VerifiedScene(pair,ta,tb,false,true,"OWNER_AUDIT"));
        check(outcomes.size()==1,"one output");
        check(outcomes.get(0).budget().issuedQ()==10,"force peak 42 -> 10");
        check(outcomes.get(0).budget().allocation().total()==10,"credit accounting");
        check(outcomes.get(0).logLine().contains("worldMutation=OFF"),"no world change");
        var again=NativeEffectGroups.aggregate("minecraft:overworld",4,raw);
        var duplicate=bridge.handle(again,g->new GameImpactDispatch.VerifiedScene(pair,ta,tb,false,true,"OWNER_AUDIT"));
        check(!duplicate.get(0).successful(),"rest duplication veto");
        // A contact after the four diagnostic samples can carry the largest force.
        var fresh=new GameImpactDispatch(new GameImpactCredit(Settings.provisional()));
        fresh.engine().step(new Frame(pair,1,List.of(),true,false,ta,tb));
        fresh.engine().step(new Frame(pair,2,List.of(),true,false,ta,tb));
        double[] six=new double[6*15];
        for(int i=0;i<6;i++){six[i*15]=23;six[i*15+1]=-1;six[i*15+2]=i==5?42:3;}
        var late=NativeEffectGroups.aggregate("minecraft:overworld",3,six);
        check(late.groups().get(0).samples().size()==4,"diagnostic samples remain bounded");
        check(late.groups().get(0).forcePeak()==42,"late force retained for credit");
        var lateCredit=fresh.handle(late,g->new GameImpactDispatch.VerifiedScene(pair,ta,tb,false,true,"OWNER_AUDIT"));
        check(lateCredit.get(0).budget().issuedQ()==10,"late peak not dropped by 4-sample cap");
        var invalid=six.clone();invalid[15]=Double.NaN;
        var reject=fresh.handle(NativeEffectGroups.aggregate("minecraft:overworld",4,invalid),
                g->new GameImpactDispatch.VerifiedScene(pair,ta,tb,false,true,"OWNER_AUDIT"));
        check(reject.get(0).budget()==null && reject.get(0).rejectReason().equals("INCOMPLETE_NATIVE_BATCH"),
                "one invalid record blocks approving incomplete batch");
        var huge=new double[(NativeEffectGroups.MAX_RECORDS+1)*15];
        for(int i=0;i<huge.length/15;i++){
            huge[i*15]=23;huge[i*15+1]=-1;huge[i*15+2]=42;
        }
        var cap=NativeEffectGroups.aggregate("minecraft:overworld",5,huge);
        check(cap.discardedRecords()==1,"overflow counted");
        var capReject=fresh.handle(cap,g->new GameImpactDispatch.VerifiedScene(pair,ta,tb,false,true,"OWNER_AUDIT"));
        check(capReject.get(0).budget()==null,"overflow cannot issue credit");
        System.out.println("GameImpactDispatchFixture PASS count="+checks);
    }
}
