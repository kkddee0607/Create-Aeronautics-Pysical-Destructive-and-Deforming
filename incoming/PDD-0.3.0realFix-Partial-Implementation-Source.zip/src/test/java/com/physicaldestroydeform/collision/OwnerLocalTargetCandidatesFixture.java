package com.physicaldestroydeform.collision;

import java.util.List;
import java.util.Set;
import static com.physicaldestroydeform.collision.OwnerLocalTargetCandidates.*;

public final class OwnerLocalTargetCandidatesFixture {
    private static int checks;
    private static void check(boolean b,String m) {checks++;if(!b)throw new AssertionError(m);}
    public static void main(String[] args) {
        var resolver=OwnerLocalTargetCandidates.provisional();
        Inspector one=(owner,p)->new Evidence(owner,p,"minecraft:stone",true,
                p.equals(new Block(10,64,10)),true,false);
        var r1=new Request("PLOT:1",true,new Block(10,64,10),true,null,false,
                null,false,List.of());
        check(resolver.resolve(r1,one).verified(),"callback block verified");
        check(resolver.resolve(r1,one).stage()==Stage.R1_EXISTING_CALLBACK,"R1 precedence");
        var noOwner=new Request("PLOT:1",false,new Block(10,64,10),true,null,false,
                null,false,List.of());
        check(resolver.resolve(noOwner,one).reason()==Reason.OWNER_UNVERIFIED,"owner mandatory");
        var r2=new Request("PLOT:1",true,null,false,new Point(10.5,64.5,10.5),true,
                null,false,List.of());
        check(resolver.resolve(r2,one).verified(),"calibrated R2 verified");
        check(resolver.resolve(r2,one).stage()==Stage.R2_COLLIDER_POSE,"R2 priority");
        var rawOnly=new Request("PLOT:1",true,null,false,new Point(10.5,64.5,10.5),false,
                null,false,List.of());
        check(resolver.resolve(rawOnly,one).reason()==Reason.TARGET_UNRESOLVED,
                "raw collider local point never directly used");
        var r3=new Request("PLOT:1",true,null,false,null,false,
                new Point(10.5,64.5,10.5),true,List.of());
        check(resolver.resolve(r3,one).stage()==Stage.R3_CROSS_SIDE,"R3 calibrated cross side");
        var nearEdge=new Request("PLOT:1",true,null,false,
                new Point(10.0001,64.5,10.5),true,null,false,List.of());
        check(resolver.resolve(nearEdge,one).checkedCandidates()==2,"boundary two candidates");
        Inspector many=(owner,p)->new Evidence(owner,p,"minecraft:stone",true,true,true,false);
        check(resolver.resolve(nearEdge,many).reason()==Reason.TARGET_AMBIGUOUS,
                "border two real blocks ambiguous");
        // Ambiguous R2 is not a license to choose an arbitrary first block;
        // independently calibrated cross-side evidence can still identify one.
        var rescue=new Request("PLOT:1",true,null,false,
                new Point(10.0001,64.5,10.5),true,
                new Point(10.5,64.5,10.5),true,List.of());
        check(resolver.resolve(rescue,many).reason()==Reason.VERIFIED,
                "unique R3 rescues ambiguous R2");
        check(resolver.resolve(rescue,many).stage()==Stage.R3_CROSS_SIDE,
                "fallback retains provenance");
        var swept=new Request("PLOT:1",true,null,false,null,false,null,false,List.of(new Block(10,64,10)));
        check(resolver.resolve(swept,one).reason()==Reason.PROVISIONAL_ONLY,"R4 provisional");
        check(!resolver.resolve(swept,one).verified(),"R4 not allowed to mint damage");
        var unloaded=(Inspector)(owner,p)->new Evidence(owner,p,"minecraft:stone",false,true,true,false);
        check(resolver.resolve(r1,unloaded).reason()==Reason.TARGET_UNRESOLVED,"no chunk loads");
        var protectedBlock=(Inspector)(owner,p)->new Evidence(owner,p,"minecraft:stone",true,true,true,true);
        check(resolver.resolve(r1,protectedBlock).reason()==Reason.TARGET_UNRESOLVED,"protected veto");
        var invalid=new Request("PLOT:1",true,null,false,new Point(Double.NaN,64,10),true,
                null,false,List.of());
        check(resolver.resolve(invalid,one).reason()==Reason.NONFINITE_POINT,"NaN refused");
        System.out.println("OwnerLocalTargetCandidatesFixture PASS count="+checks);
    }
}
